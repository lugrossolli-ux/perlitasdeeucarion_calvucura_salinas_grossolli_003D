package com.example.productos.repository;

import com.example.productos.model.ProductoMaterial;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProductoMaterialRepository extends JpaRepository<ProductoMaterial, Long> {
    List<ProductoMaterial> findByProductoId(Long productoId);
}